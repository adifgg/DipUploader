const app = document.getElementById("app");
document.getElementById("site-name").textContent = SITE.nama;
document.title = SITE.nama;

const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const hue = s => [...String(s)].reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
const catName = id => (CATEGORIES.find(c => c.id === id) || {}).nama || id;
const inCat = id => id === "semua" ? APPS : APPS.filter(a => a.kategori === id);

function icon(a) {
  return a.ikon ? `<img class="ikon" src="${esc(a.ikon)}" alt="">`
    : `<span class="ikon huruf" style="--h:${hue(a.nama)}">${esc(a.nama[0])}</span>`;
}

function home() {
  app.innerHTML = `<nav class="crumb"><b>Home</b></nav><h1>Semua Kategori</h1><div class="cats">` +
    CATEGORIES.map(c => {
      const bg = c.gambar ? `background-image:url('${esc(c.gambar)}');` : "";
      return `<a class="cat" href="#cat-${esc(c.id)}"><div class="cat-img" style="${bg}--h:${hue(c.nama)}">
        <span class="pill">${inCat(c.id).length} Apps</span></div>
        <div class="cat-b"><span class="nm">${esc(c.nama)}</span><span style="color:var(--blue)">&rarr;</span></div></a>`;
    }).join("") + `</div>`;
}

function list(catId) {
  if (!CATEGORIES.some(c => c.id === catId)) return home();
  app.innerHTML = `<nav class="crumb"><a href="#">Home</a> &gt; <b>${esc(catName(catId))}</b></nav>
    <h1>${esc(catName(catId))}</h1>
    <input class="search" id="q" type="search" placeholder="Cari aplikasi..." aria-label="Cari aplikasi">
    <div class="list" id="list"></div>`;
  const draw = q => {
    const items = inCat(catId).filter(a => a.nama.toLowerCase().includes(q.toLowerCase()));
    document.getElementById("list").innerHTML = items.length ? items.map(a => `
      <a class="item" href="#app-${esc(a.id)}">
        <div class="row">${icon(a)}<div class="info">
          <div class="nm"><span>${esc(a.nama)}</span>${a.baru ? '<span class="badge">NEW</span>' : ""}</div>
          <div class="dev">${esc(a.developer)}</div></div></div>
        <div class="meta"><span>v${esc(a.versi)}</span><span>${esc(a.ukuran)}</span></div></a>`).join("")
      : `<p class="empty">Belum ada aplikasi yang cocok.</p>`;
  };
  draw("");
  document.getElementById("q").addEventListener("input", e => draw(e.target.value));
}

function detail(id) {
  const a = APPS.find(x => x.id === id);
  if (!a) return home();
  app.innerHTML = `<nav class="crumb"><a href="#">Home</a> &gt; <a href="#cat-${esc(a.kategori)}">${esc(catName(a.kategori))}</a> &gt; <b>${esc(a.nama)}</b></nav>
    <div class="hero">${icon(a)}<div><h1>${esc(a.nama)}</h1>
      <div class="dev">${esc(a.developer)} &middot; ${esc(catName(a.kategori))}</div>
      ${a.baru ? '<span class="badge" style="display:inline-block;margin-top:8px">NEW</span>' : ""}</div></div>
    <div class="stats">
      <div><b>${esc(a.versi)}</b><span>Versi</span></div>
      <div><b>${esc(a.ukuran)}</b><span>Ukuran</span></div>
    </div>
    <a class="dl" href="${esc(a.unduh)}" rel="noopener">&#8595; Unduh Sekarang</a>
    <div class="sec"><button class="btn" id="share">Bagikan</button></div>`;
  document.getElementById("share").onclick = async e => {
    const data = { title: a.nama, url: location.href };
    try { navigator.share ? await navigator.share(data) : (await navigator.clipboard.writeText(location.href), e.target.textContent = "Link disalin"); } catch (_) {}
  };
}

function route() {
  const h = location.hash.slice(1);
  if (h.startsWith("cat-")) list(h.slice(4));
  else if (h.startsWith("app-")) detail(h.slice(4));
  else home();
  window.scrollTo(0, 0);
}
addEventListener("hashchange", route);
route();
