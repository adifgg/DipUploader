// ===== EDIT FILE INI SAJA untuk memperbarui konten =====
const SITE = { nama: "APK STORE" };

// id kategori dipakai di tiap aplikasi (kolom "kategori"). "semua" = otomatis tampil semua.
const CATEGORIES = [
  { id: "semua",  nama: "Semua apps", gambar: "" },
  { id: "nonton", nama: "Nonton",     gambar: "" },
  { id: "social", nama: "Social",     gambar: "" },
  { id: "tools",  nama: "Tools",      gambar: "" }
];

// Tambah aplikasi baru = salin satu blok { ... } lalu ubah isinya.
// ikon boleh dikosongkan (ikon kosong = huruf awal otomatis).
const APPS = [
  { id: "Speedx", nama: "Speedx", developer: "Chermodsc", kategori: "tools",
    versi: "2.5.5", ukuran: "4.8 MB",
    baru: true, ikon: "speedx.webp", unduh: "https://www.mediafire.com/file/ik4quv8ss1e874w/Speed-X_2.5.5-NewUpdate.apk/file" },
];
